PROCESSO DE ADMISS�O ZUP - GUSTAVO CAMPOS DE SOUZA BARBOSA

APLICA��O: XY INC.

DESCRI��O: Aplica��o focada na constru��o de um servidor local preparado para receber requisi��es e processa-las adequadamente.

PR�-REQUISITOS: MongoDB, NodeJs e mocha (opcional).

GUIA DE EXECU��O: 
1. Primeiramente acesse o Prompt de comando, execute o comando 'mongod', para iniciar o MongoDB; nota: N�o Feche esse Prompt de comando ou execute quaisquer comandos para n�o para a execu��o do banco de dados.
2. Abra outro Prompt de comando, execute o comando 'cd C:\Users\"local-do-projeto"\src' para acessar a pasta do projeto e por fim execute o comando 'node app.js';
3. Uma vez em que os o banco est� ativo e o projeto em execu��o, voc� poder� acessar a aplica��o pela porta '8081';
4. PATHS: 
4.1 Listar Pontos de interesse: 'http://localhost:8081/APIXY/list' [GET];
4.2 Cadastrar Ponto de interesse: 'http://localhost:8081/APIXY/register' [POST];
4.3 Procurar Ponto de interesse proximo: 'http://localhost:8081/APIXY/find' [GET];
5. FORMATA��O DO JSON PARA ENVIO:
5.1 Cadastrar Ponto de interesse:
{

	"coordenadaX": 10,

	"coordenadaY": 10,
	"nome": "locadora"

}


5.2 Procurar Ponto de Interesse proximo:
{

	"coordenadaX": 10,

	"coordenadaY": 10
}

6 TESTES AUTOMATIZADOS:
6.1 Abra outro Prompt de comando, execute o comando 'cd C:\Users\"local-do-projeto"\src' para acessar a pasta do projeto e por fim execute o comando 'mocha', ser� executado uma bateria de testes com base no arquivo 'record.js' dentro da pasta de testes.

AUTORIA: GUSTAVO CAMPOS DE SOUZA BARBOSA