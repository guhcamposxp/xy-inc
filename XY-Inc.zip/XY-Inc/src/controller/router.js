const express = require('express');
const POI = require('../model/POI');
const router = express.Router();

router.post('/register', async (req, res) => {
    try {

        var json = req.body;

        if (!(json['coordenadaX'] >= 0)) { return res.status(400).send({ error: 'Favor incluir campo de coordenada X: coordenadaX, com um valor inteiro maior ou igual a 0' }); }
        if (!(json['coordenadaY'] >= 0)) { return res.status(400).send({ error: 'Favor incluir campo de coordenada Y: coordenadaY, com um valor inteiro maior ou igual a 0' }); }

        const poi = await POI.create(req.body);

        return res.send('Ponto de Interesse criado com sucesso');
    } catch (error) {
        // console.log(err);
        return res.status(400).send({ error: 'Falha ao registrar o Ponto de interesse' });
    }

});

router.get('/list', async (req, res) => {
    try {
        const resp = await POI.find({});

        return res.send({ resp });

    } catch (error) {
        return res.status(400).send({ error: 'Falha ao listar os Pontos de Interesse' });
    }
});

router.get('/find', async (req, res) => {
    try {
        // const users = await POI.find({});

        const json = req.body;

        if (!(json['coordenadaX'] >= 0)) { return res.status(400).send({ error: 'Favor incluir campo de coordenada X: coordenadaX, com um valor inteiro maior ou igual a 0' }); }
        if (!(json['coordenadaY'] >= 0)) { return res.status(400).send({ error: 'Favor incluir campo de coordenada Y: coordenadaY, com um valor inteiro maior ou igual a 0' }); }

        // var options = { near: [json['coordenadaX'], json['coordenadaY']], maxDistance: json['distanciaMax'] };
        // var x = parseInt(json['coordenadaX'], 10);

        const pois = await POI.find();

        const response = [];

        pois.forEach((poi, index) => {
            const referenciaX = poi['coordenadaX'] - json['coordenadaX'];
            const referenciaY = poi['coordenadaY'] - json['coordenadaY'];

            const distancia = Math.sqrt(Math.pow(referenciaX, 2) + Math.pow(referenciaY, 2));

            if (distancia <= 10) {
                response.push(poi);
            }
        })

        return res.send(response);

    } catch (error) {
        console.log(error);
        return res.status(400).send({ error: 'Falha ao listar diretorios' });
    }
});

module.exports = app => app.use('/APIXY', router);