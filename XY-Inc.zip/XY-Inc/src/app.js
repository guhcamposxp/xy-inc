const express = require('express');
const bodyParse = require('body-parser');
const app = express();

app.use(bodyParse.json());
app.use(bodyParse.urlencoded({ extended: false}));

require('./controller/router')(app);

app.listen(8081);

module.exports = app;