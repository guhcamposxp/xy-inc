const chai = require('chai');
const serv = require('../app');
const chaiHtml = Request('chai-html');
const poi = require('../model/POI');
const should = chai.should();

chai.use(chaiHtml);

describe('poi', () => {

    //zera o banco
    before((next) => {
        poi.remove({}, (error) => {
            next();
        });
    });

    it('Cadastra Ponto de Interesse', (done) => {

        var novoP = {
            coordenadaX: 10,
            coordenadaY: 10,
            nome: "locadora"
        };

        chai.Request(serv)
        .post('APIXY/register')
        .send(novoP)
        .end((error, res)=>{
            
            res.should.have.status(200);

            done();
        });

    });

    it('Lista Pontods de Interesse', (done) => {

        chai.Request(serv)
        .get('APIXY/list')
        .end((error, res)=>{
            
            res.should.have.status(200);

            done();
        });

    });

    it('Procura Ponto de Interesse Proximos', (done) => {

        var novoP = {
            coordenadaX: 10,
            coordenadaY: 10
        };

        chai.Request(serv)
        .get('APIXY/register')
        .send(novoP)
        .end((error, res)=>{
            
            res.should.have.status(200);

            done();
        });

    });
});