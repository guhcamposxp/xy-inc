const mongoose = require('../database/ConnectBD');

const POISchema = new mongoose.Schema({
    nome: {
        type: String,
        required: true
    },
    coordenadaX: {
        type: Number,
        required: true
    },
    coordenadaY: {
        type: Number,
        required: true
    }
});

const POI = mongoose.model('POI', POISchema);

module.exports = POI;